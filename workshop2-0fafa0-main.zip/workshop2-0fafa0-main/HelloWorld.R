
print('Hello world!')
print('I am a sentient machine')

x <- 1 < 2 & 3 >= 3
x
